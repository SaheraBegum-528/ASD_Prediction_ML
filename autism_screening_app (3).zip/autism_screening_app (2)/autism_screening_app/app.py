# -*- coding: utf-8 -*-
from flask import Flask, render_template, request, redirect, url_for
import pandas as pd
import numpy as np
from sklearn import model_selection
from sklearn.metrics import classification_report, accuracy_score
from keras.models import Sequential
from keras.layers import Dense
from keras.optimizers import Adam
import os
from keras.models import load_model

app = Flask(__name__)

# Global variables
model = None
X_columns = None
model_trained = False

def create_model():
    model = Sequential()
    model.add(Dense(8, input_dim=96, kernel_initializer='normal', activation='relu'))
    model.add(Dense(4, kernel_initializer='normal', activation='relu'))
    model.add(Dense(2, activation='sigmoid'))
    
    adam = Adam(learning_rate=0.001)
    model.compile(loss='categorical_crossentropy', optimizer=adam, metrics=['accuracy'])
    return model

def load_data():
    file_path = 'Autism-Child-Data.txt'
    data = pd.read_table(file_path, sep=',', index_col=None)
    data = data.drop(['result', 'age_desc'], axis=1)
    
    x = data.drop(columns=['Class'])
    y = data['Class']
    
    X = pd.get_dummies(x)
    Y = pd.get_dummies(y)
    
    return X, Y

def train_model():
    global model, X_columns, model_trained
    
    X, Y = load_data()
    X_columns = X.columns.tolist()
    
    # Convert all data to float32
    X = X.astype(np.float32)
    Y = Y.astype(np.float32)
    
    X_train, X_test, Y_train, Y_test = model_selection.train_test_split(
        X, Y, test_size=0.2, random_state=42)
    
    model = create_model()
    model.fit(X_train, Y_train, epochs=50, batch_size=10, verbose=1)
    
    predictions = np.argmax(model.predict(X_test), axis=-1)
    accuracy = accuracy_score(Y_test[['YES']], predictions)
    report = classification_report(Y_test[['YES']], predictions)
    
    if not os.path.exists('models'):
        os.makedirs('models')
    model.save('models/autism_model.h5')
    
    model_trained = True
    return accuracy, report

def ensure_model_loaded():
    global model, X_columns, model_trained
    
    if not model_trained:
        if os.path.exists('models/autism_model.h5'):
            model = load_model('models/autism_model.h5')
            X_sample, _ = load_data()
            X_columns = X_sample.columns.tolist()
            model_trained = True
        else:
            print("Training new model...")
            accuracy, report = train_model()
            print(f"Model trained with accuracy: {accuracy}")
            print("Classification Report:")
            print(report)

def prepare_input(form_data):
    # Create empty DataFrame with correct columns
    input_df = pd.DataFrame(columns=X_columns)
    input_df.loc[0] = 0  # Initialize all values to 0
    
    # Convert all values to float32
    input_df = input_df.astype(np.float32)
    
    # Process form data
    for key, value in form_data.items():
        if key in ['A1_Score', 'A2_Score', 'A3_Score', 'A4_Score', 'A5_Score', 
                  'A6_Score', 'A7_Score', 'A8_Score', 'A9_Score', 'A10_Score', 'age']:
            input_df[key] = np.float32(value)
        else:
            column_name = f"{key}_{value}"
            if column_name in X_columns:
                input_df[column_name] = np.float32(1)
    
    # Ensure all columns are present and of correct type
    missing_cols = set(X_columns) - set(input_df.columns)
    for col in missing_cols:
        input_df[col] = np.float32(0)
    
    return input_df[X_columns]  # Return with columns in correct order

@app.route('/')
def home():
    ensure_model_loaded()
    return render_template('index.html')

@app.route('/train', methods=['GET', 'POST'])
def train():
    if request.method == 'POST':
        accuracy, report = train_model()
        return render_template('result.html', 
                            message="Model trained successfully!",
                            accuracy=accuracy,
                            report=report)
    return render_template('train.html')

@app.route('/predict', methods=['POST'])
def predict():
    ensure_model_loaded()
    
    if model is None:
        return render_template('result.html', 
                            message="Model not trained yet. Please train the model first.",
                            accuracy=0,
                            report="")
    
    try:
        input_df = prepare_input(request.form.to_dict())
        prediction = np.argmax(model.predict(input_df), axis=-1)[0]
        result = "YES" if prediction == 1 else "NO"
        
        return render_template('result.html', 
                           message=f"Prediction Result: {result}",
                           prediction=result)
    except Exception as e:
        return render_template('result.html',
                           message=f"Error making prediction: {str(e)}",
                           prediction="ERROR")

if __name__ == '__main__':
    app.run(debug=True)